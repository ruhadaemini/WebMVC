<?php

namespace mvcwebsite\controllers;


class PagesController {

    public function index() {

    }

}