<?php

$title = "Home Page";

require __DIR__ . '/../app/views/coin-flip.view.php';