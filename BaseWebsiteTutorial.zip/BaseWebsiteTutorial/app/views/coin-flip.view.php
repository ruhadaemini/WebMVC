<?php
require 'partials/head.php';
?>
<header>
    <h1>Coin-Flip Result</h1>
</header>

<p>
    <?= $coin; ?>
</p>

<?php
require 'partials/foot.php';
?>
