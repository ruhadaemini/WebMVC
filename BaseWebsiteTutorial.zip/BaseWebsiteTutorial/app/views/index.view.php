<?php
require 'partials/head.php';
?>
<header>
    <h1>Welcome to the MVC from scratch tutorial</h1>
</header>
<?php
require 'partials/foot.php';
?>
