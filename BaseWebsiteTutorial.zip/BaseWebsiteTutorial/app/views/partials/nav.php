<nav>
    <ul>
        <li><a href="index">Home</a></li>
        <li><a href="coin-flip">Coin-Flip</a></li>
    </ul>
</nav>