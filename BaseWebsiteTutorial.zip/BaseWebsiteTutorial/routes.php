<?php
 return [
     '' => '../app/controllers/index.php',
     'index' => '../app/controllers/index.php',

     'register'=>'../app/'
 ];