<?php
//
//$coin = "Tails";
//
//if (rand(0, 1)){
//    $coin = "Head";
//}
//
// require '../app/views/coin-flip.view.php'
//
//?>