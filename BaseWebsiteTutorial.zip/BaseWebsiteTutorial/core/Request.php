<?php
/**
 * Created by PhpStorm.
 * User: e030549h
 * Date: 13/03/2018
 * Time: 10:36
 */

namespace core;


class Request
{
    public static function uri(){
        return trim($_SERVER['REQUEST_URI'], '/');
    }
}