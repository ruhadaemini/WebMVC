<?php
/**
 * Created by PhpStorm.
 * User: e030549h
 * Date: 13/03/2018
 * Time: 10:15
 */

namespace core;


class Router
{
    private $routes = [];

    private function register(array $routes){
        $this->routes = $routes;
    }

    public static function load($file){

        $router = new static;

        $router->register(require $file);

        return $router;

    }

    public function direct ($uri){
        if (array_key_exists($uri, $this->routes)){

            return  $this->routes[$uri];

        }
        else{

            throw new \Exception('Resource not found');

        }
    }
}